"""
acoustic_model.py
Hourly A-weighted fan noise of the proposed system's hybrid cooler and of the
conventional dry cooler, computed from the hourly fan speeds that hybrid_model.py
already produces. Nothing in hybrid_model.py is changed; this module only reads its
hourly outputs.

Source model
  Sound power at full fan speed is scaled from the same commercial dry cooler that sets the
  footprint scaling in hybrid_model.py (250 kW, 40/35 C water, 25 C air: UA = 16.7 kW/K),
  whose datasheet gives 62.3 dB(A) at 10 m. Assuming hemispherical free-field radiation
  from a roof or ground-mounted unit, that is LwA = 62.3 + 20 log10(10) + 8 = 90.3 dB(A).
  A coil of conductance UA uses proportionally more (or fewer) fans of the same type:
      LwA,full = 90.3 + 10 log10(UA / 16.7)
  At part speed the fan law for sound power applies (ASHRAE: 50 log10 of the speed ratio):
      LwA(s) = LwA,full + k log10(s),  k = 50
  where s is the hourly fan speed fraction, recovered from the cube-law fan power that
  hybrid_model.hybrid_cooler() returns: s = (P_fan / P_full)^(1/3). While the adiabatic
  pads are wetted the fans work against the extra pad pressure drop; this is represented
  by a fixed increment (central +2 dB, tested at 0 and +4 dB).

Propagation
  Hemispherical spreading from a point source (ISO 9613-2:2024 with ground and barrier terms
  and atmospheric absorption omitted, which is conservative at these distances):
      LpA(r) = LwA - 20 log10(r) - 8
  Central receiver distance 10 m, tested at 25 m and 50 m.

This is a preliminary source-receiver screening calculation, not a compliance assessment: it
uses one datasheet rating, a fan law and free-field spreading, with no spectra, directivity,
barriers or site measurements.

Assessment periods
  Regulatory day 07:00-22:00 and night 22:00-07:00 (as in, e.g., Los Angeles Municipal Code
  Sec. 111.03, with presumed residential ambient levels of 50 dB(A) day and 40 dB(A) night,
  and Sec. 112.02, under which HVAC and pumping equipment may not make the noise level on another
  occupied property exceed the ambient by more than 5 dB). Two counts are reported: source-only
  (cooler level above ambient + 5 dB) and combined (ambient + cooler above ambient + 5 dB, the form
  of the LAMC test). The Los Angeles criteria are used as one illustrative benchmark for all seven
  climates, not as the governing rule in each city.
  Also reported for the model's own night definition (GHI < 5 W/m2), in which the PVT
  array carries the rejection duty.

Outdoor sources not modelled: pumps (inside the host's plant room), water flow on the PVT
film, and any tonal or low-frequency penalty. A fan-off hour therefore contributes no
modelled outdoor mechanical noise.
"""
from dataclasses import dataclass
import numpy as np

LW_REF_DBA = 62.3 + 20.0 * np.log10(10.0) + 8.0     # 90.3 dB(A), datasheet unit
UA_REF_KW_K = 250.0 / 15.0                           # 16.7 kW/K, same unit as hm.DRY_M2_PER_UA
DAY_HOURS = np.arange(7, 22)                         # 07:00-22:00
NIGHT_HOURS = np.array([22, 23, 0, 1, 2, 3, 4, 5, 6])  # 22:00-07:00


@dataclass
class AcousticConfig:
    lw_ref: float = LW_REF_DBA
    ua_ref: float = UA_REF_KW_K
    k_speed: float = 50.0        # fan-law exponent for sound power, dB per decade of speed
    pad_dB: float = 2.0          # increment while adiabatic pads are wetted
    r_m: float = 10.0            # receiver distance
    amb_day: float = 50.0        # presumed ambient, dB(A)
    amb_night: float = 40.0
    margin: float = 5.0          # permitted excess over ambient


def lw_full(UA, ac: AcousticConfig):
    return ac.lw_ref + 10.0 * np.log10(UA / ac.ua_ref)


def hourly_lw(fan_kWh, fan_on, pads_on, UA, P_full, ac: AcousticConfig):
    """Hourly LwA (dB(A)); -inf in hours with the fans off."""
    fan_kWh = np.asarray(fan_kWh, float)
    on = np.asarray(fan_on, bool) & (fan_kWh > 0)
    s = np.where(on, np.cbrt(np.clip(fan_kWh / P_full, 1e-12, 1.0)), 1.0)
    lw = lw_full(UA, ac) + ac.k_speed * np.log10(s) + ac.pad_dB * np.asarray(pads_on, float)
    return np.where(on, lw, -np.inf), np.where(on, s, 0.0)


def lp_at(lw, ac: AcousticConfig):
    return lw - 20.0 * np.log10(ac.r_m) - 8.0


def leq(levels):
    """Energy average over the hours given (fan-off hours, -inf, count as silence)."""
    levels = np.asarray(levels, float)
    if levels.size == 0:
        return -np.inf
    e = np.mean(np.where(np.isfinite(levels), 10.0 ** (levels / 10.0), 0.0))
    return 10.0 * np.log10(e) if e > 0 else -np.inf


def add_db(a, b):
    return 10.0 * np.log10(10.0 ** (a / 10.0) + np.where(np.isfinite(b), 10.0 ** (b / 10.0), 0.0))


def _fin(x):
    """JSON-safe: -inf (no source) is written as None."""
    return float(x) if np.isfinite(x) else None


def period_metrics(lp, mask, ambient, ac: AcousticConfig, group=None):
    """Metrics for the hours in mask. group: integer label per hour used to form the
    per-day (or per-night) LAeq, from which the worst period is taken."""
    x = lp[mask]
    on = np.isfinite(x)
    L = leq(x)
    rise_hourly = add_db(ambient, x) - ambient
    out = {
        "hours": int(mask.sum()), "fan_h": int(on.sum()),
        "LAeq": _fin(L),
        "rise_over_ambient_dB": float(add_db(ambient, L) - ambient),
        # source-only screen: cooler level alone above ambient + margin
        "h_over_ambient_plus_margin": int((x > ambient + ac.margin).sum()),
        # compliance-style test (e.g. LAMC 112.02): total level (ambient + cooler) above ambient + margin,
        # i.e. cooler level above ambient + 10 log10(10^(margin/10) - 1) (3.35 dB for a 5 dB margin)
        "h_combined_over_limit": int((rise_hourly > ac.margin).sum()),
        "source_threshold_dBA": float(ambient + 10.0 * np.log10(10.0 ** (ac.margin / 10.0) - 1.0)),
        "h_over_ambient": int((x > ambient).sum()),
        "h_rise_ge_3dB": int((rise_hourly >= 3.0).sum()),
        "Lmax_hourly": _fin(x.max()) if on.any() else None,
        "L50_running": _fin(np.percentile(x[on], 50)) if on.any() else None,
        "L95_running": _fin(np.percentile(x[on], 95)) if on.any() else None,
    }
    if group is not None:
        g = group[mask]
        per = [leq(x[g == k]) for k in np.unique(g)]
        per = np.array(per)
        out["worst_period_LAeq"] = _fin(per.max()) if np.isfinite(per).any() else None
        out["periods_over_ambient_plus_margin"] = int((per > ambient + ac.margin).sum())
        out["periods_combined_over_limit"] = int(((add_db(ambient, per) - ambient) > ac.margin).sum())
        out["periods_with_fans"] = int(np.isfinite(per).sum())
    return out


def assess(lp, night_ghi, ac: AcousticConfig):
    h = np.arange(8760)
    hod = h % 24
    day_mask = np.isin(hod, DAY_HOURS)
    night_mask = np.isin(hod, NIGHT_HOURS)
    day_id = h // 24
    night_id = (h + 2) // 24            # 22:00 and 23:00 belong to the following night
    return {
        "day": period_metrics(lp, day_mask, ac.amb_day, ac, day_id),
        "night": period_metrics(lp, night_mask, ac.amb_night, ac, night_id),
        "ghi_night": period_metrics(lp, np.asarray(night_ghi, bool), ac.amb_night, ac),
        "ghi_day": period_metrics(lp, ~np.asarray(night_ghi, bool), ac.amb_day, ac),
    }


def diff(a, b):
    """a - b in dB, with None (no source) handled: returns None if either side is silent."""
    if a is None or b is None:
        return None
    return a - b
