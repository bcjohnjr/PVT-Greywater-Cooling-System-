"""Reproducibility check.

Quick mode (default, about 30 s):
    python reproduce_check.py
reruns the Phoenix 130.5 kW (Case B) central case and its tower baseline and compares
them with results_published/results.json.

Full mode (after `python run_all.py`):
    python reproduce_check.py --full
compares every numeric value in the freshly generated results/results.json with
results_published/results.json.

Exits with status 0 if all values agree within a relative tolerance of 1e-9.
"""
import os, sys, json
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = HERE if os.path.isdir(os.path.join(HERE, "weather")) else os.path.dirname(HERE)
sys.path.insert(0, HERE)
REF = os.path.join(ROOT, "results_published", "results.json")
NEW = os.path.join(ROOT, "results", "results.json")
RTOL = 1e-9


def walk(a, b, path, bad, n):
    if isinstance(a, dict):
        for k in a:
            if k not in b:
                bad.append(f"{path}/{k}: missing in new results")
            else:
                n = walk(a[k], b[k], f"{path}/{k}", bad, n)
    elif isinstance(a, list):
        if len(a) != len(b):
            bad.append(f"{path}: length {len(a)} vs {len(b)}")
        else:
            for i, (x, y) in enumerate(zip(a, b)):
                n = walk(x, y, f"{path}[{i}]", bad, n)
    elif isinstance(a, (int, float)) and not isinstance(a, bool):
        n += 1
        if not np.isclose(a, b, rtol=RTOL, atol=1e-9):
            bad.append(f"{path}: published {a!r}, new {b!r}")
    elif a != b:
        bad.append(f"{path}: published {a!r}, new {b!r}")
    return n


def quick():
    from dataclasses import replace
    import hybrid_model as hm
    ref = json.load(open(REF))
    cfg = hm.Config(n_acc=72, n_panels=200, dry_kW_35=40.0)
    f, _ = hm.CLIMATES["Phoenix"]
    w = hm.load_epw(os.path.join(ROOT, "weather", f))
    S = hm.simulate(w, "Phoenix", cfg)
    Qc = cfg.it_rated_kW * cfg.util * cfg.capture
    T = hm.simulate_tower(w, np.full(8760, Qc), replace(hm.TowerConfig(), T_hot=cfg.T_hot))
    bad = []
    n = 0
    for k, v in ref["main"]["B"]["Phoenix"].items():
        n += 1
        if not np.isclose(v, S[k], rtol=RTOL, atol=1e-9):
            bad.append(f"main/B/Phoenix/{k}: published {v!r}, new {S[k]!r}")
    for k, v in ref["compare"]["B"]["Phoenix"]["tower_full"].items():
        if isinstance(v, (int, float)):
            n += 1
            if not np.isclose(v, T[k], rtol=RTOL, atol=1e-9):
                bad.append(f"tower_full/{k}: published {v!r}, new {T[k]!r}")
    if bad:
        print(f"FAIL: {len(bad)} differences")
        for b in bad:
            print("  ", b)
        sys.exit(1)
    print(f"PASS (quick): {n} values for Phoenix, Case B, match the published results "
          f"(water {S['water_total_m3']:.4f} m3, cooling electricity {S['cool_elec_MWh']:.4f} MWh, "
          f"unmet {S['unmet_MWh']:.4f} MWh, night fan hours {S['fan_night_h']})")


if __name__ == "__main__":
    if "--full" in sys.argv:
        ref = json.load(open(REF))
        new = json.load(open(NEW))
        bad = []
        n = walk(ref, new, "", bad, 0)
        if bad:
            print(f"FAIL: {len(bad)} differences")
            for b in bad[:30]:
                print("  ", b)
            sys.exit(1)
        print(f"PASS (full): all {n} numeric values in results/results.json match the published results")
        aref = os.path.join(ROOT, "results_published", "acoustics.json")
        anew = os.path.join(ROOT, "results", "acoustics.json")
        if os.path.exists(anew):
            bad = []
            n = walk(json.load(open(aref)), json.load(open(anew)), "acoustics", bad, 0)
            if bad:
                print(f"FAIL (acoustics): {len(bad)} differences")
                for b in bad[:30]:
                    print("  ", b)
                sys.exit(1)
            print(f"PASS (full): all {n} numeric values in results/acoustics.json match the published results")
        else:
            print("results/acoustics.json not found: run python run_acoustics.py to check the fan-noise results")
    else:
        quick()
