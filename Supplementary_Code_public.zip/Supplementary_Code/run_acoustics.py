"""Fan-noise comparison of the proposed system and the conventional dry cooler.

    python run_acoustics.py            -> results/acoustics.json   (about 3 min)
    python run_acoustics.py --check    -> also compares with results_published/acoustics.json

Uses the hourly fan output of hybrid_model.simulate() and the dry cooler of
hybrid_model.dry_cooler_baseline() (same sizing rules, re-run hourly here) and converts
fan speed to A-weighted sound power and sound pressure with acoustic_model.py.
"""
import os, sys, json
from dataclasses import replace
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import hybrid_model as hm
import acoustic_model as am

ROOT = HERE if os.path.isdir(os.path.join(HERE, "weather")) else os.path.dirname(HERE)
WDIR = os.path.join(ROOT, "weather")
OUT = os.path.join(ROOT, "results")
os.makedirs(OUT, exist_ok=True)

CASES = {
    "A": hm.Config(n_acc=32, n_panels=100, dry_kW_35=30.0),
    "B": hm.Config(n_acc=72, n_panels=200, dry_kW_35=40.0),
}


def dry_hourly(w, R, T_hot=45.0, sizing="design", design_pct=99.6, fan_kW_per_kW=0.03):
    """Hourly fan output of the dry cooler, with exactly the sizing of hm.dry_cooler_baseline."""
    R = np.asarray(R, float)
    dT = T_hot - w["T"]
    if sizing == "reliability":
        UA = float(np.max(np.where(R > 1e-9, R / np.maximum(dT, 1e-3), 0.0)))
    else:
        UA = float(R.max() / max(T_hot - np.percentile(w["T"], design_pct), 0.5))
    cfg = hm.Config(dry_kW_35=UA * 10.0, T_hot=T_hot, T_hot_rating=45.0, adiabatic_on=False,
                    fan_kW_per_kW=fan_kW_per_kW)
    fan = np.zeros(8760); on = np.zeros(8760, bool)
    for h in range(8760):
        o = hm.hybrid_cooler(R[h], w["T"][h], w["Twb"][h], cfg)
        fan[h], on[h] = o["fan_kWh"], o["fan_on"]
    return dict(fan=fan, on=on, pads=np.zeros(8760, bool), UA=UA, P_full=fan_kW_per_kW * UA * 10.0)


def prop_hourly(H, cfg):
    UA = cfg.dry_kW_35 / (cfg.T_hot_rating - 35.0)
    return dict(fan=H["fan_kWh"], on=H["fan_on"].astype(bool), pads=H["pads_on"].astype(bool),
                UA=UA, P_full=cfg.fan_kW_per_kW * cfg.dry_kW_35)


def film_hygiene_bound(H, cfg):
    """Upper bound for a separate weekly thermal flush of the PVT film circuit: one extra flush in
    every week in which the film ran but the pad-loop flush was not already triggered. Same volume,
    temperatures, losses and booster as the pad-loop flush in hybrid_model.py."""
    wk = np.arange(8760) // 168
    film_wk = set(np.unique(wk[H["w_film"] > 0]))
    flush_wk = set(np.unique(wk[H["w_steril"] > 0]))
    extra = len(film_wk - flush_wk)
    kWh = (cfg.steril_m3 * 1000 * 4.186 * (cfg.steril_T_C - cfg.steril_preheat_C) / 3600.0
           * cfg.steril_loss_factor / cfg.steril_heater_COP)
    return {"film_weeks": len(film_wk), "pad_flush_weeks": len(flush_wk), "extra_flushes": extra,
            "extra_water_m3": extra * cfg.steril_m3, "extra_elec_MWh": extra * kWh / 1000.0}


def levels(src, ac):
    lw, s = am.hourly_lw(src["fan"], src["on"], src["pads"], src["UA"], src["P_full"], ac)
    return am.lp_at(lw, ac), lw, s


def compare(w, P, D, ac):
    lpP, lwP, sP = levels(P, ac)
    lpD, lwD, sD = levels(D, ac)
    aP, aD = am.assess(lpP, w["night"], ac), am.assess(lpD, w["night"], ac)
    both = np.isfinite(lpP) & np.isfinite(lpD)
    hod = np.arange(8760) % 24
    dmask = np.isin(hod, am.DAY_HOURS)
    m = both & dmask
    d_hourly = lpP[m] - lpD[m]
    out = {"prop": aP, "dry": aD,
           "LwA_full": {"prop": float(am.lw_full(P["UA"], ac)), "dry": float(am.lw_full(D["UA"], ac))},
           "UA": {"prop": P["UA"], "dry": D["UA"]},
           "delta_day_LAeq": am.diff(aP["day"]["LAeq"], aD["day"]["LAeq"]),
           "delta_night_LAeq": am.diff(aP["night"]["LAeq"], aD["night"]["LAeq"]),
           "delta_day_worst": am.diff(aP["day"]["worst_period_LAeq"], aD["day"]["worst_period_LAeq"]),
           "delta_night_rise": aP["night"]["rise_over_ambient_dB"] - aD["night"]["rise_over_ambient_dB"],
           "day_hourly_delta_when_both_run": {
               "n": int(d_hourly.size),
               "median": float(np.median(d_hourly)) if d_hourly.size else None,
               "p5": float(np.percentile(d_hourly, 5)) if d_hourly.size else None,
               "p95": float(np.percentile(d_hourly, 95)) if d_hourly.size else None,
               "share_prop_louder": float((d_hourly > 0).mean()) if d_hourly.size else None},
           "mean_speed_running": {"prop": float(sP[sP > 0].mean()) if (sP > 0).any() else 0.0,
                                  "dry": float(sD[sD > 0].mean()) if (sD > 0).any() else 0.0}}
    return out, lpP, lpD


def main():
    W = {c: hm.load_epw(os.path.join(WDIR, f)) for c, (f, z) in hm.CLIMATES.items()}
    ac0 = am.AcousticConfig()
    R = {"acoustic_config": ac0.__dict__.copy(), "central": {}, "sens": {}, "pvt_unc": {}, "profile": {},
         "check_fan_night_h": {}}
    SENS = {"r_m": [25.0, 50.0], "k_speed": [40.0, 60.0], "pad_dB": [0.0, 4.0]}
    # PVT capacity uncertainty, evaluated with the quiet-hours dispatch
    PVT_UNC = {"full_x0.74": dict(pvt_derate=0.74, pvt_shoulder=True),
               "full_x0.50": dict(pvt_derate=0.50, pvt_shoulder=True),
               "bare_x0.74": dict(pvt_mech="bare", pvt_derate=0.74, pvt_shoulder=True),
               "bare_x0.50": dict(pvt_mech="bare", pvt_derate=0.50, pvt_shoulder=True)}
    QUIET = {"central": dict(), "night_shift": dict(night_shift=True), "pvt_shoulder": dict(pvt_shoulder=True),
             "shoulder_and_shift": dict(pvt_shoulder=True, night_shift=True)}
    for case, cfg in CASES.items():
        R["central"][case], R["sens"][case], R["pvt_unc"][case] = {}, {}, {}
        R["profile"][case], R["check_fan_night_h"][case] = {}, {}
        for c, w in W.items():
            S = hm.simulate(w, c, cfg, keep_hourly=True); H = S.pop("hourly")
            P = prop_hourly(H, cfg)
            Dd = dry_hourly(w, H["resid"], cfg.T_hot, "design")
            Dr = dry_hourly(w, H["resid"], cfg.T_hot, "reliability")
            R["check_fan_night_h"][case][c] = {"prop": int((P["on"] & w["night"]).sum()),
                                              "dry_design": int((Dd["on"] & w["night"]).sum())}
            out, lpP, lpD = compare(w, P, Dd, ac0)
            out["reliability"] = compare(w, P, Dr, ac0)[0]
            R["central"][case][c] = out
            # mean diurnal profile of hourly LpA (energy mean over the year, fan-off as silence)
            hod = np.arange(8760) % 24
            R["profile"][case][c] = {
                "prop": [am._fin(am.leq(lpP[hod == k])) for k in range(24)],
                "dry": [am._fin(am.leq(lpD[hod == k])) for k in range(24)],
                "prop_hours_on": [int(np.isfinite(lpP[hod == k]).sum()) for k in range(24)],
                "dry_hours_on": [int(np.isfinite(lpD[hod == k]).sum()) for k in range(24)]}
            R["sens"][case][c] = {}
            for p, vals in SENS.items():
                for v in vals:
                    R["sens"][case][c][f"{p}={v}"] = compare(w, P, Dd, replace(ac0, **{p: v}))[0]
            for lab, kw in PVT_UNC.items():
                cu = replace(cfg, **kw)
                Su = hm.simulate(w, c, cu, keep_hourly=True); Hu = Su.pop("hourly")
                Du = dry_hourly(w, Hu["resid"], cu.T_hot, "design")
                R["pvt_unc"][case][c] = R["pvt_unc"][case].get(c, {})
                R["pvt_unc"][case][c][lab] = compare(w, prop_hourly(Hu, cu), Du, ac0)[0]
            # quiet-hours dispatch variants: what keeping fans off through 22:00-07:00 costs
            R.setdefault("quiet", {}).setdefault(case, {})[c] = {}
            for lab, kw in QUIET.items():
                cq = replace(cfg, **kw)
                Sq = hm.simulate(w, c, cq, keep_hourly=True); Hq = Sq.pop("hourly")
                Dq = dry_hourly(w, Hq["resid"], cq.T_hot, "design")
                o, lpq, lpdq = compare(w, prop_hourly(Hq, cq), Dq, ac0)
                o["profile"] = {"prop": [am._fin(am.leq(lpq[hod == k])) for k in range(24)],
                                "dry": [am._fin(am.leq(lpdq[hod == k])) for k in range(24)]}
                o["system"] = {k: Sq[k] for k in ["water_total_m3", "water_municipal_m3", "cool_elec_MWh",
                                                  "unmet_MWh", "fan_night_h", "fan_h", "useful_MWh",
                                                  "shoulder_h", "shoulder_pvt_MWh", "shift_MWh"]}
                o["film_hygiene"] = film_hygiene_bound(Hq, cq)
                R["quiet"][case][c][lab] = o
            # hybrid-coil rating: a larger coil turns its fans more slowly by day (Case B only)
            if case == "B":
                R.setdefault("coil", {}).setdefault(case, {})[c] = {}
                q40 = R["quiet"][case][c]["pvt_shoulder"]
                Sq40 = hm.simulate(w, c, replace(cfg, pvt_shoulder=True))
                q40["system"]["rej_elec_MWh"] = Sq40["cool_elec_MWh"] - cfg.pump_kW_per_kW * Sq40["useful_MWh"]
                q40["system"]["coil_installed_m2"] = cfg.dry_kW_35 / 10.0 * hm.DRY_M2_PER_UA * hm.DRY_INSTALL_FACTOR
                for q35 in [70.0, 100.0]:
                    cc = replace(cfg, dry_kW_35=q35, pvt_shoulder=True)
                    Sc = hm.simulate(w, c, cc, keep_hourly=True); Hc = Sc.pop("hourly")
                    Dc = dry_hourly(w, Hc["resid"], cc.T_hot, "design")
                    o = compare(w, prop_hourly(Hc, cc), Dc, ac0)[0]
                    o["system"] = {k: Sc[k] for k in ["water_total_m3", "water_municipal_m3", "cool_elec_MWh",
                                                      "unmet_MWh", "fan_night_h"]}
                    o["system"]["rej_elec_MWh"] = Sc["cool_elec_MWh"] - cc.pump_kW_per_kW * Sc["useful_MWh"]
                    o["system"]["coil_installed_m2"] = q35 / 10.0 * hm.DRY_M2_PER_UA * hm.DRY_INSTALL_FACTOR
                    o["film_hygiene"] = film_hygiene_bound(Hc, cc)
                    R["coil"][case][c][str(q35)] = o
            print("acoustics", case, c, flush=True)
    with open(os.path.join(OUT, "acoustics.json"), "w") as f:
        json.dump(R, f, indent=1)
    print("written results/acoustics.json")
    return R


if __name__ == "__main__":
    main()
    if "--check" in sys.argv:
        import reproduce_check as rc
        ref = json.load(open(os.path.join(ROOT, "results_published", "acoustics.json")))
        new = json.load(open(os.path.join(OUT, "acoustics.json")))
        bad = []
        n = rc.walk(ref, new, "", bad, 0)
        print(f"acoustics: {n} numeric values compared, {len(bad)} differences")
        for b in bad[:20]:
            print("  ", b)
        sys.exit(1 if bad else 0)
