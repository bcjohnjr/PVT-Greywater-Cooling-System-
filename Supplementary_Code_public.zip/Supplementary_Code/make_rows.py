"""Derive table rows and comparison percentages from results.json -> rows.json."""
import os, json
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = HERE if os.path.isdir(os.path.join(HERE, "weather")) else os.path.dirname(HERE)  # package or working tree
RES = os.path.join(ROOT, "results")
R = json.load(open(os.path.join(RES, "results.json")))
pct = lambda a, b: (a / b - 1) * 100
rows = {}
for case in "AB":
    rows[case] = []
    for c in R["climate"]:
        S = R["main"][case][c]; C = R["compare"][case][c]; it = C["it_kWh"]
        tf, tr = C["tower_full"], C["tower_resid"]
        rej = S["pvt_passive_MWh"] + S["pvt_film_MWh"] + S["dry_MWh"] + S["adia_MWh"]
        Erej = S["cool_elec_MWh"] - 0.008 * S["useful_MWh"]
        rows[case].append(dict(
            c=c, W=S["water_total_m3"], Wm=S["water_municipal_m3"], WUE=S["WUE_total_L_kWh"],
            tW=tf["water_m3"], tWUE=tf["water_m3"] * 1000 / it, dW=pct(S["water_total_m3"], tf["water_m3"]),
            E=S["cool_elec_MWh"], tE=tf["elec_MWh"], dE=pct(S["cool_elec_MWh"], tf["elec_MWh"]),
            Ewh=S["cool_elec_MWh"] * 1e6 / it, tEwh=tf["elec_MWh"] * 1e6 / it,
            Erej=Erej, trW=tr["water_m3"], trE=tr["elec_MWh"], dWr=pct(S["water_total_m3"], tr["water_m3"]), dEr=pct(Erej, tr["elec_MWh"]),
            fl=tf["latent_frac_mean"], fanN=S["fan_night_h"], silent=S["silent_share"],
            passive_share=S["pvt_passive_MWh"] / rej, unmet=S["unmet_MWh"], unmet_h=S["unmet_h"],
            nopvtW=C["hybrid_noPVT_municipal"]["water_total_m3"], nopvtE=C["hybrid_noPVT_municipal"]["cool_elec_MWh"],
            nopvtFanN=C["hybrid_noPVT_municipal"]["fan_night_h"], nopvtU=C["hybrid_noPVT_municipal"]["unmet_MWh"],
            nopvtRecW=C["hybrid_noPVT_recycled"]["water_total_m3"], nopvtRecE=C["hybrid_noPVT_recycled"]["cool_elec_MWh"],
            munW=C["proposed_municipal"]["water_total_m3"], dryU=C["dry_only_noPVT"]["unmet_MWh"], dryUh=C["dry_only_noPVT"]["unmet_h"],
            ffW=C["night_fan_first"]["water_total_m3"], ffN=C["night_fan_first"]["fan_night_h"], ffE=C["night_fan_first"]["cool_elec_MWh"],
            shW=C["night_shift"]["water_total_m3"], shE=C["night_shift"]["cool_elec_MWh"], shFan=C["night_shift"]["fan_h"],
            shUseful=C["night_shift"]["useful_MWh"], fanh=S["fan_h"],
            pvtP=S["pvt_passive_MWh"], pvtF=S["pvt_film_MWh"], dry=S["dry_MWh"], adia=S["adia_MWh"], resid=S["resid_MWh"],
            useful=S["useful_MWh"], perm=S["permeate_m3"], film=S["water_film_m3"], pad=S["water_pad_m3"],
            ster=S["water_steril_m3"], padh=S["pad_h"], fanMWh=S["fan_MWh"], pump=S["pump_MWh"], ro=S["ro_MWh"],
            sterE=S["steril_MWh"], nflush=S["n_flush"], umaxf=S["unmet_max_frac_IT"], uef=S["unmet_energy_frac_IT"]))
json.dump(rows, open(os.path.join(RES, "rows.json"), "w"), indent=1)
print("rows written")
