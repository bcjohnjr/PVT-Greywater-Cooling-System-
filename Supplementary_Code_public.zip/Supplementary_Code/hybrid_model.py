"""
hybrid_model.py
Hourly model of a recycled-wash-water hybrid heat-rejection system for a
liquid-cooled GPU module co-located with a laundromat or car wash.

Rejection hierarchy
  night (GHI below threshold): fanless PVT array (passive mechanisms),
      then PVT evaporative film, then hybrid cooler (dry, then adiabatic)
  day: PVT array is in solar-collection mode; hybrid cooler (dry, then adiabatic)
Water: host greywater -> pretreatment -> reverse osmosis -> unheated buffer
tank -> PVT film and adiabatic pads; municipal top-up when the tank is empty.

The PVT surface energy balance is imported unchanged from
pvt_full_system_model.py (supplied alongside this file).

Requirements: Python 3, NumPy. Deterministic.
"""
import os, sys, json, copy
from dataclasses import dataclass, field, asdict, replace
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pvt_full_system_model as pvt  # noqa: E402

CP_AIR = 1.006      # kJ/(kg K)
H_FG = 2430.0       # kJ/kg, latent heat near 25-30 C

CLIMATES = {
    "Phoenix":       ("USA_AZ_Phoenix-Sky.Harbor.Intl.AP.722780_TMY3.epw", "2B hot-dry"),
    "Las Vegas":     ("USA_NV_Las.Vegas-McCarran.Intl.AP.723860_TMY3.epw", "3B warm-dry"),
    "Fresno":        ("USA_CA_Fresno.Air.Terminal.723890_TMY3.epw", "3B warm-dry (Mediterranean)"),
    "San Francisco": ("USA_CA_San.Francisco.Intl.AP.724940_TMY3.epw", "3C marine"),
    "Miami":         ("USA_FL_Miami.Intl.AP.722020_TMY3.epw", "1A hot-humid"),
    "Chicago":       ("USA_IL_Chicago-OHare.Intl.AP.725300_TMY3.epw", "5A cold-humid"),
    "Los Angeles":   ("USA_CA_Los.Angeles.Intl.AP.722950_TMY3.epw", "3B warm-dry (coastal)"),
}


# ----------------------------------------------------------------------------
# Weather
# ----------------------------------------------------------------------------
def load_epw(path):
    rows = []
    with open(path, encoding="latin-1") as f:
        for i, line in enumerate(f):
            if i == 0:
                hdr = line.strip().split(",")
            if i < 8:
                continue
            p = line.strip().split(",")
            rows.append(p)
    a = lambda k: np.array([float(r[k]) for r in rows])
    w = {
        "month": a(1).astype(int), "day": a(2).astype(int), "hour": a(3).astype(int),
        "T": a(6), "Tdp": a(7), "RH": np.clip(a(8), 1, 100) / 100.0,
        "P": a(9), "GHI": a(13), "DNI": a(14), "DHI": a(15), "wind": a(21),
        "lat": float(hdr[6]), "lon": float(hdr[7]), "tz": float(hdr[8]),
        "cloud": np.clip(np.where(a(23) > 10, a(22), a(23)), 0, 10) / 10.0,
    }
    assert len(w["T"]) == 8760, path
    w["Twb"] = np.array([pvt.wet_bulb_stull(t, rh) for t, rh in zip(w["T"], w["RH"])])
    w["night"] = w["GHI"] < 5.0
    return w


# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------
@dataclass
class Config:
    # compute module
    n_acc: int = 32                 # B300-equivalent accelerators
    kw_per_acc: float = 1.8125      # rated kW per accelerator-equivalent
    util: float = 0.80              # flat IT power fraction
    capture: float = 0.85           # liquid-loop capture fraction
    # host
    host: str = "laundromat"        # laundromat | carwash | commercial_laundry
    cl_kg_per_day: float = 10000.0  # commercial laundry throughput (Mon-Sat, 06:00-22:00)
    cl_kWh_per_kg: float = 0.40     # wash-water heat per kg of linen
    cl_L_per_kg: float = 8.0        # fresh water per kg (tunnel washer), discharged as greywater
    # daytime PVT solar preheating of host wash water (after GPU heat and store)
    pvt_preheat: bool = True
    boiler_eff: float = 0.85        # host water heater efficiency (fuel displaced = heat / eff)
    gas_kgCO2_per_kWh: float = 0.181  # natural gas combustion, per kWh of fuel
    f_T: float = 0.60               # temperature-compatible share of host heat demand
    store_kWh: float = 110.0        # 1,000 US gal, 25 K swing
    # PVT array (geometry from pvt_full_system_model.Geometry)
    pvt_on: bool = True
    T_panel: float = 40.0
    n_panels: int = 100
    film_allowed: bool = True
    pvt_derate: float = 1.0          # multiplier on modelled PVT capacity (1/1.35 = benchmark-calibrated)
    # enhancement mechanisms included in the PVT model: "full" (plenum stack, shrouds, emitter,
    # thermosiphon), "bare" (none: the configuration benchmarked against measurements), or
    # "no_stack" / "no_shroud" / "no_emitter" / "no_thermo" (one mechanism removed)
    pvt_mech: str = "full"
    # hybrid cooler
    T_hot: float = 45.0             # fluid temperature entering cooler
    dry_kW_35: float = 30.0         # dry capacity at 35 C entering air with 45 C fluid (rating point)
    T_hot_rating: float = 45.0      # fluid temperature at which dry_kW_35 is rated; fixes coil UA
    dT_air_design: float = 10.0     # air temperature rise across coil at design flow
    pad_eff: float = 0.85           # adiabatic pad saturation effectiveness
    fan_kW_per_kW: float = 0.03     # fan power at full speed per kW of design capacity
    fan_min_frac: float = 0.20
    adiabatic_on: bool = True
    coc_pad_recycled: float = 10.0  # cycles of concentration on RO permeate
    coc_pad_municipal: float = 3.0
    # night dispatch order: "silent" = PVT film before fans; "fan" = fans before PVT film
    night_order: str = "silent"
    # quiet-hours PVT rejection: in hours of the regulatory night (22:00-07:00) that are already
    # light (GHI >= 5 W/m2, i.e. summer dawn), let the PVT array keep its rejection duty, with its
    # night-time capacity reduced by the absorbed solar flux not converted to electricity
    # (panel temperature fixed, so the surface balance changes only by that term). Off by default.
    pvt_shoulder: bool = False
    shoulder_hours: tuple = (22, 23, 0, 1, 2, 3, 4, 5, 6)
    shoulder_alpha_net: float = 0.70   # solar absorptance 0.90 minus electrical efficiency 0.20
    # thermal-store night shift: discharge store into spare passive PVT capacity at night
    night_shift: bool = False
    night_shift_floor: float = 0.0  # fraction of store kept for the morning
    # water recycling
    recycle_on: bool = True
    grey_L_per_load: float = 60.0      # laundromat greywater per wash load
    grey_L_per_service: float = 40.0   # car-wash water divertible to treatment per vehicle
    grey_capture: float = 0.90
    ro_recovery: float = 0.60
    ro_max_m3_h: float = 0.30          # permeate capacity
    tank_m3: float = 2.0
    steril_m3: float = 0.20            # weekly thermal-sterilization flush when pads used
    steril_T_C: float = 70.0           # flush temperature
    steril_preheat_C: float = 40.0     # preheat from the 45 C loop through a heat exchanger
    steril_loss_factor: float = 1.25   # heat-up and hold losses
    steril_heater_COP: float = 1.0     # electric-resistance booster (conservative)
    seed_tank_frac: float = 0.5
    # auxiliary electricity
    pump_kW_per_kW: float = 0.008      # loop pumping per kW of heat sent to a rejection device
    ro_kWh_per_m3: float = 2.0         # pretreatment + low-pressure RO per m3 permeate
    uv_kWh_per_m3: float = 0.05        # UV disinfection of permeate
    film_pump_kWh_per_m3: float = 0.15

    @property
    def it_rated_kW(self): return self.n_acc * self.kw_per_acc


def host_profile(cfg: Config):
    """Hourly heat demand (kWh_th) and greywater (m3) for one year."""
    hrs = np.arange(8760)
    hod = hrs % 24
    dow = (hrs // 24) % 7          # 0 = Monday
    weekend = dow >= 5
    if cfg.host == "laundromat":
        open_h, close_h = 7, 22
        per_day = np.where(weekend, 160.0, 110.0)
        kwh_per, L_per = 4.96, cfg.grey_L_per_load
        shape = np.array([0, 0, 0, 0, 0, 0, 0, 3, 5, 7, 8, 8, 8, 7, 7, 7, 8, 9, 9, 8, 6, 4, 2, 0], float)
    elif cfg.host == "carwash":
        open_h, close_h = 7, 20
        per_day = np.where(weekend, 260.0, 180.0)
        kwh_per, L_per = 2.88, cfg.grey_L_per_service
        shape = np.array([0, 0, 0, 0, 0, 0, 0, 3, 6, 8, 9, 10, 10, 10, 10, 10, 10, 9, 7, 4, 0, 0, 0, 0], float)
    else:  # commercial_laundry: events are kg of linen
        per_day = np.where(dow == 6, 0.0, cfg.cl_kg_per_day)
        kwh_per, L_per = cfg.cl_kWh_per_kg, cfg.cl_L_per_kg
        shape = np.array([0] * 6 + [1] * 16 + [0] * 2, float)
    shape = shape / shape.sum()
    events = per_day * shape[hod]
    heat = events * kwh_per
    grey = events * L_per / 1000.0
    return heat, grey, events


# ----------------------------------------------------------------------------
# PVT capacity tables (precomputed per climate and panel temperature)
# ----------------------------------------------------------------------------
FILM_DUTIES = np.array([0.0, 0.15, 0.30, 0.50, 0.75, 1.0])
_PVT_CACHE = {}


MECH = {
    "full": {},
    "bare": dict(plenum_stack=False, shrouds=False, emitter_deployed=False, thermosiphon=False),
    "no_stack": dict(plenum_stack=False), "no_shroud": dict(shrouds=False),
    "no_emitter": dict(emitter_deployed=False), "no_thermo": dict(thermosiphon=False),
}


def pvt_tables(w, climate, T_panel, n_panels, mech="full"):
    key = (climate, T_panel, n_panels, mech)
    if key in _PVT_CACHE:
        return _PVT_CACHE[key]
    g = pvt.Geometry(n_panels=n_panels)
    cap = np.zeros((8760, len(FILM_DUTIES)))
    water = np.zeros_like(cap)          # make-up kg/h
    idx = np.where(w["night"])[0]
    for i in idx:
        env = pvt.Environment(T_amb_C=w["T"][i], RH=w["RH"][i],
                              wind_speed=max(w["wind"][i], 0.0),
                              cloud_fraction=w["cloud"][i])
        for j, d in enumerate(FILM_DUTIES):
            st = pvt.MechanismState(film=d > 0, film_duty=d if d > 0 else 0.30,
                                    mist=False, ehd=False, **MECH[mech])
            r = pvt.evaluate(env, g, st, T_panel)
            cap[i, j] = max(r["P_kW"], 0.0)
            water[i, j] = r["m_makeup"] * 3600.0
    # enforce monotone capacity in duty (frozen hours give identical columns)
    cap = np.maximum.accumulate(cap, axis=1)
    _PVT_CACHE[key] = (cap, water, g.A_total)
    return _PVT_CACHE[key]


def shoulder_tables(w, climate, cfg, mask, A_pvt):
    """PVT capacity and film water in light hours of the regulatory night: the night-time
    surface balance at the same panel temperature, minus the absorbed solar flux that is not
    converted to electricity. Film evaporation at fixed panel temperature is unchanged."""
    key = ("shoulder", climate, cfg.T_panel, cfg.n_panels, cfg.pvt_mech, cfg.shoulder_hours)
    if key not in _PVT_CACHE:
        g = pvt.Geometry(n_panels=cfg.n_panels)
        cap = np.zeros((8760, len(FILM_DUTIES))); water = np.zeros_like(cap)
        for i in np.where(mask)[0]:
            env = pvt.Environment(T_amb_C=w["T"][i], RH=w["RH"][i],
                                  wind_speed=max(w["wind"][i], 0.0), cloud_fraction=w["cloud"][i])
            for j, d in enumerate(FILM_DUTIES):
                st = pvt.MechanismState(film=d > 0, film_duty=d if d > 0 else 0.30,
                                        mist=False, ehd=False, **MECH[cfg.pvt_mech])
                r = pvt.evaluate(env, g, st, cfg.T_panel)
                cap[i, j] = max(r["P_kW"], 0.0)
                water[i, j] = r["m_makeup"] * 3600.0
        _PVT_CACHE[key] = (np.maximum.accumulate(cap, axis=1), water)
    cap, water = _PVT_CACHE[key]
    _, poa = pv_hourly(w, 1.0)
    q_sol = cfg.shoulder_alpha_net * poa * A_pvt / 1000.0          # kW absorbed, not converted
    cap = np.clip(cap - q_sol[:, None], 0.0, None) * cfg.pvt_derate
    return cap, water * cfg.pvt_derate


def pvt_film_for(load, cap_row, water_row):
    """Smallest film duty (linear interpolation) meeting load. Returns (Q, water kg)."""
    if load <= cap_row[0] + 1e-9:
        return load, 0.0
    if load >= cap_row[-1]:
        return cap_row[-1], water_row[-1]
    j = int(np.searchsorted(cap_row, load))
    c0, c1 = cap_row[j - 1], cap_row[j]
    x = (load - c0) / max(c1 - c0, 1e-9)
    return load, water_row[j - 1] + x * (water_row[j] - water_row[j - 1])


# ----------------------------------------------------------------------------
# Hybrid cooler
# ----------------------------------------------------------------------------
def hybrid_cooler(load, T, Twb, cfg: Config):
    """Return dict(Q_dry, Q_adia, evap_kg, fan_kWh, unmet) for one hour."""
    out = dict(Q_dry=0.0, Q_adia=0.0, evap_kg=0.0, fan_kWh=0.0, unmet=0.0, fan_on=False, pads_on=False)
    if load <= 1e-9 or cfg.dry_kW_35 <= 0:
        out["unmet"] = max(load, 0.0)
        return out
    UA = cfg.dry_kW_35 / (cfg.T_hot_rating - 35.0)       # kW/K, fixed physical coil
    P_full = cfg.fan_kW_per_kW * cfg.dry_kW_35
    m_air = cfg.dry_kW_35 / (CP_AIR * cfg.dT_air_design)  # kg/s at full speed
    q_dry_max = UA * max(cfg.T_hot - T, 0.0)
    out["fan_on"] = True
    if q_dry_max >= load:
        f = max(load / q_dry_max, cfg.fan_min_frac)
        out["Q_dry"] = load
        out["fan_kWh"] = P_full * f ** 3
        return out
    out["Q_dry"] = q_dry_max
    out["fan_kWh"] = P_full
    rem = load - q_dry_max
    if not cfg.adiabatic_on:
        out["unmet"] = rem
        return out
    dT_pre_max = cfg.pad_eff * max(T - Twb, 0.0)
    dT_need = rem / UA
    dT_pre = min(dT_need, dT_pre_max)
    q_adia = UA * dT_pre
    out["Q_adia"] = q_adia
    out["pads_on"] = dT_pre > 0
    out["evap_kg"] = m_air * CP_AIR * dT_pre / H_FG * 3600.0
    out["unmet"] = rem - q_adia
    return out


# ----------------------------------------------------------------------------
# Daytime PV electricity of the PVT array (and of plain PV on the same roof)
# ----------------------------------------------------------------------------
@dataclass
class PVConfig:
    tilt_deg: float = 30.0          # same tilt as the PVT geometry
    azimuth: str = "south"
    eta_stc: float = 0.20           # module efficiency at STC
    gamma: float = -0.0040          # power temperature coefficient, 1/K
    noct: float = 45.0              # uncooled module (conservative for a fluid-cooled PVT)
    losses: float = 0.14            # inverter, wiring, soiling, mismatch, availability
    albedo: float = 0.20


def pv_hourly(w, area_m2, pv: PVConfig = PVConfig()):
    """Hourly AC electricity (kWh) from area_m2 of south-facing modules.
    Isotropic-sky transposition of the TMY3 DNI/DHI; NOCT cell temperature."""
    hrs = np.arange(8760)
    n = hrs // 24 + 1
    t_std = (hrs % 24) + 0.5                                   # mid-hour, local standard time
    B = np.radians(360.0 * (n - 81) / 364.0)
    eot = 9.87 * np.sin(2 * B) - 7.53 * np.cos(B) - 1.5 * np.sin(B)   # minutes
    t_sol = t_std + (4.0 * (w["lon"] - 15.0 * w["tz"]) + eot) / 60.0
    omega = np.radians(15.0 * (t_sol - 12.0))
    dec = np.radians(23.45 * np.sin(np.radians(360.0 * (284 + n) / 365.0)))
    phi, beta = np.radians(w["lat"]), np.radians(pv.tilt_deg)
    cos_z = np.sin(phi) * np.sin(dec) + np.cos(phi) * np.cos(dec) * np.cos(omega)
    cos_i = np.sin(dec) * np.sin(phi - beta) + np.cos(dec) * np.cos(phi - beta) * np.cos(omega)
    beam = np.where(cos_z > 0.02, w["DNI"] * np.clip(cos_i, 0, None), 0.0)
    poa = beam + w["DHI"] * (1 + np.cos(beta)) / 2 + w["GHI"] * pv.albedo * (1 - np.cos(beta)) / 2
    Tc = w["T"] + (pv.noct - 20.0) / 800.0 * poa
    p_kw = area_m2 * pv.eta_stc * poa / 1000.0 * (1 + pv.gamma * (Tc - 25.0)) * (1 - pv.losses)
    return np.clip(p_kw, 0, None), poa


def mains_temperature(w):
    """Hourly mains-water temperature (C), Burch & Christensen (2007) correlation as used in EnergyPlus."""
    TF = w["T"] * 9 / 5 + 32
    mon = np.array([TF[w["month"] == m].mean() for m in range(1, 13)])
    tavg = TF.mean(); dmax = mon.max() - mon.min()
    ratio = 0.4 + 0.01 * (tavg - 44.0); lag = 35.0 - 1.0 * (tavg - 44.0)
    day = np.arange(8760) // 24 + 1
    tm = (tavg + 6.0) + ratio * (dmax / 2.0) * np.sin(np.radians(0.986 * (day - 15 - lag) - 90.0))
    return (tm - 32) * 5 / 9


# Certified unglazed PVT collector, ISO 9806:2013 (inlet temperature, gross area): SRCC OG-100 2007044A
PVT_TH = dict(eta0=0.337, bu=0.0755, b1=10.112, b2=0.2417, eps_alpha=1.0)


def pvt_thermal_hourly(w, area_m2, T_in, pv: PVConfig = PVConfig(), c=PVT_TH):
    """Daytime useful heat (kWh per hour) of the PVT array heating water entering at T_in."""
    _, poa = pv_hourly(w, area_m2, pv)
    sig = 5.670e-8
    Ta_K = w["T"] + 273.15
    eps = np.array([pvt.Environment(T_amb_C=t, RH=rh, cloud_fraction=cl).eps_sky
                    for t, rh, cl in zip(w["T"], w["RH"], w["cloud"])])
    EL_minus = sig * Ta_K ** 4 * (eps - 1.0)                 # incoming longwave minus sigma Ta^4 (W/m2)
    G2 = poa + c["eps_alpha"] * EL_minus
    u = np.maximum(w["wind"], 0.0)
    q = c["eta0"] * (1 - c["bu"] * u) * G2 - (c["b1"] + c["b2"] * u) * (T_in - w["T"])
    q = np.where((poa > 50.0) & (~w["night"]), np.clip(q, 0, None), 0.0)
    return area_m2 * q / 1000.0


# ----------------------------------------------------------------------------
# Conventional dry-cooler baseline (dry coil only, no pads, no PVT, no water)
# ----------------------------------------------------------------------------
DRY_M2_PER_UA = 4.30 * 1.31 / (250.0 / 15.0)   # m2 plan area per kW/K (datasheet: 250 kW, 40->35 C water, 25 C air)
DRY_INSTALL_FACTOR = 2.0                        # plan area incl. airflow and service clearance


def dry_cooler_baseline(w, R, T_hot=45.0, sizing="reliability", design_pct=99.6,
                        fan_kW_per_kW=0.03, pump_kW_per_kW=0.008, fan_min_frac=0.20):
    """Dry-only cooler rejecting the hourly heat series R (kW).
    sizing="reliability": smallest coil that meets R in every hour (no compute curtailment).
    sizing="design": coil meets max(R) at the design_pct percentile dry-bulb (ASHRAE 0.4% for 99.6)."""
    R = np.asarray(R, float)
    dT = T_hot - w["T"]
    if sizing == "reliability":
        UA = float(np.max(np.where(R > 1e-9, R / np.maximum(dT, 1e-3), 0.0)))
    else:
        UA = float(R.max() / max(T_hot - np.percentile(w["T"], design_pct), 0.5))
    Q35 = UA * 10.0
    cfg = Config(dry_kW_35=Q35, T_hot=T_hot, T_hot_rating=45.0, adiabatic_on=False,
                 fan_kW_per_kW=fan_kW_per_kW, fan_min_frac=fan_min_frac)
    fan = np.zeros(8760); on = np.zeros(8760, bool); unmet = np.zeros(8760)
    for h in range(8760):
        o = hybrid_cooler(R[h], w["T"][h], w["Twb"][h], cfg)
        fan[h], on[h], unmet[h] = o["fan_kWh"], o["fan_on"], o["unmet"]
    pump = pump_kW_per_kW * (R.sum() - unmet.sum())
    A_unit = UA * DRY_M2_PER_UA
    return {"UA_kW_K": UA, "Q35_kW": Q35, "fan_MWh": fan.sum() / 1000, "pump_MWh": pump / 1000,
            "elec_MWh": (fan.sum() + pump) / 1000, "fan_h": int(on.sum()),
            "fan_night_h": int((on & w["night"]).sum()), "unmet_MWh": unmet.sum() / 1000,
            "unmet_h": int((unmet > 0.01).sum()), "area_unit_m2": A_unit,
            "area_installed_m2": A_unit * DRY_INSTALL_FACTOR, "fan_full_kW": fan_kW_per_kW * Q35}


# ----------------------------------------------------------------------------
# Annual simulation
# ----------------------------------------------------------------------------
def simulate(w, climate, cfg: Config, keep_hourly=False):
    heat_dem, grey, _ = host_profile(cfg)
    it = cfg.it_rated_kW * cfg.util
    Qc = it * cfg.capture
    usable = cfg.f_T * heat_dem
    if cfg.pvt_on:
        cap, wat, A_pvt = pvt_tables(w, climate, cfg.T_panel, cfg.n_panels, cfg.pvt_mech)
        if cfg.pvt_derate != 1.0:
            cap, wat = cap * cfg.pvt_derate, wat * cfg.pvt_derate
    else:
        cap = wat = None
        A_pvt = 0.0

    shoulder = np.zeros(8760, bool)
    if cfg.pvt_on and cfg.pvt_shoulder:
        shoulder = (~w["night"]) & np.isin(np.arange(8760) % 24, cfg.shoulder_hours)
        cap_s, wat_s = shoulder_tables(w, climate, cfg, shoulder, A_pvt)
    E = 0.5 * cfg.store_kWh
    tank = cfg.seed_tank_frac * cfg.tank_m3 if cfg.recycle_on else 0.0
    H = dict((k, np.zeros(8760)) for k in [
        "useful", "store", "resid", "pvt_passive", "pvt_film", "dry", "adia", "unmet",
        "w_film", "w_pad_evap", "w_pad_bleed", "w_steril", "w_total", "w_recycled",
        "w_municipal", "fan_kWh", "fan_on", "pads_on", "tank", "permeate", "shift"])
    pads_used_week = False
    for h in range(8760):
        # --- host heat use and storage -----------------------------------
        direct = min(Qc, usable[h])
        deficit = usable[h] - direct
        dis = min(E, deficit)
        E -= dis
        surplus = Qc - direct
        chg = min(surplus, cfg.store_kWh - E)
        E += chg
        resid = surplus - chg
        H["useful"][h] = direct + dis
        night = bool(w["night"][h])
        T, Twb = w["T"][h], w["Twb"][h]

        # --- rejection dispatch --------------------------------------------
        rem = resid
        q_pas = q_film = 0.0
        film_kg = 0.0
        hc = hybrid_cooler(0.0, T, Twb, cfg)
        if (night or shoulder[h]) and cfg.pvt_on:
            cap_h, wat_h = (cap_s[h], wat_s[h]) if shoulder[h] else (cap[h], wat[h])
            q_pas = min(rem, cap_h[0])
            rem -= q_pas
            if cfg.night_order == "silent":
                if rem > 1e-9 and cfg.film_allowed:
                    q_tot, film_kg = pvt_film_for(q_pas + rem, cap_h, wat_h)
                    q_film = q_tot - q_pas
                    rem -= q_film
                hc = hybrid_cooler(rem, T, Twb, cfg)
            else:
                # fans first, then film, then adiabatic
                cfg_dry = replace(cfg, adiabatic_on=False)
                hd = hybrid_cooler(rem, T, Twb, cfg_dry)
                rem2 = hd["unmet"]
                if rem2 > 1e-9 and cfg.film_allowed:
                    q_tot, film_kg = pvt_film_for(q_pas + rem2, cap_h, wat_h)
                    q_film = q_tot - q_pas
                    rem2 -= q_film
                if rem2 > 1e-9:
                    hc = hybrid_cooler(hd["Q_dry"] + rem2, T, Twb, cfg)
                else:
                    hc = hd
            # thermal-store night shift into spare passive capacity
            if cfg.night_shift:
                passive_only = q_film == 0.0 and hc["Q_dry"] == 0.0 and hc["Q_adia"] == 0.0
                spare = max(cap_h[0] - q_pas, 0.0) if passive_only else 0.0
                floor = cfg.night_shift_floor * cfg.store_kWh
                shift = min(spare, max(E - floor, 0.0))
                E -= shift
                H["shift"][h] = shift
                q_pas += shift
        else:
            hc = hybrid_cooler(rem, T, Twb, cfg)

        H["store"][h] = E
        H["resid"][h] = resid
        H["pvt_passive"][h] = q_pas
        H["pvt_film"][h] = q_film
        H["dry"][h] = hc["Q_dry"]
        H["adia"][h] = hc["Q_adia"]
        H["unmet"][h] = hc["unmet"]
        H["fan_kWh"][h] = hc["fan_kWh"]
        H["fan_on"][h] = hc["fan_on"]
        H["pads_on"][h] = hc["pads_on"]

        # --- water ------------------------------------------------------------
        coc = cfg.coc_pad_recycled if cfg.recycle_on else cfg.coc_pad_municipal
        pad_evap = hc["evap_kg"] / 1000.0
        pad_bleed = pad_evap / (coc - 1.0)
        film = film_kg / 1000.0
        if hc["pads_on"]:
            pads_used_week = True
        steril = 0.0
        if h % 168 == 167 and pads_used_week:
            steril = cfg.steril_m3
            pads_used_week = False
        demand = pad_evap + pad_bleed + film + steril
        # recycled supply into tank
        perm = 0.0
        if cfg.recycle_on:
            feed = grey[h] * cfg.grey_capture
            perm = min(feed * cfg.ro_recovery, cfg.ro_max_m3_h, cfg.tank_m3 - tank)
            tank += perm
        rec = min(demand, tank)
        tank -= rec
        mun = demand - rec
        H["permeate"][h] = perm
        H["tank"][h] = tank
        H["w_film"][h] = film
        H["w_pad_evap"][h] = pad_evap
        H["w_pad_bleed"][h] = pad_bleed
        H["w_steril"][h] = steril
        H["w_total"][h] = demand
        H["w_recycled"][h] = rec
        H["w_municipal"][h] = mun

    it_kWh = it * 8760.0
    rejected = H["pvt_passive"] + H["pvt_film"] + H["dry"] + H["adia"]
    pump_kWh = cfg.pump_kW_per_kW * (rejected.sum() + H["useful"].sum())
    ro_kWh = (cfg.ro_kWh_per_m3 + cfg.uv_kWh_per_m3) * H["permeate"].sum()
    n_flush = H["w_steril"].sum() / cfg.steril_m3 if cfg.steril_m3 > 0 else 0.0
    steril_kWh = (n_flush * cfg.steril_m3 * 1000 * 4.186 * (cfg.steril_T_C - cfg.steril_preheat_C)
                  / 3600.0 * cfg.steril_loss_factor / cfg.steril_heater_COP)
    filmpump_kWh = cfg.film_pump_kWh_per_m3 * H["w_film"].sum()
    S = {
        "pump_MWh": pump_kWh / 1000, "ro_MWh": ro_kWh / 1000, "steril_MWh": steril_kWh / 1000,
        "n_flush": int(round(n_flush)), "unmet_max_kW": float(H["unmet"].max()),
        "unmet_max_frac_IT": float(H["unmet"].max() / cfg.capture / it),
        "unmet_energy_frac_IT": float(max(H["unmet"].sum(), 0.0) / cfg.capture / (it * 8760.0)), "filmpump_MWh": filmpump_kWh / 1000,
        "climate": climate, "IT_MWh": it_kWh / 1000, "captured_MWh": Qc * 8760 / 1000,
        "useful_MWh": H["useful"].sum() / 1000, "resid_MWh": H["resid"].sum() / 1000,
        "pvt_passive_MWh": H["pvt_passive"].sum() / 1000, "pvt_film_MWh": H["pvt_film"].sum() / 1000,
        "dry_MWh": H["dry"].sum() / 1000, "adia_MWh": H["adia"].sum() / 1000,
        "unmet_MWh": max(H["unmet"].sum() / 1000, 0.0), "unmet_h": int((H["unmet"] > 0.01).sum()),
        "shift_MWh": H["shift"].sum() / 1000,
        "water_total_m3": H["w_total"].sum(), "water_film_m3": H["w_film"].sum(),
        "water_pad_m3": (H["w_pad_evap"] + H["w_pad_bleed"]).sum(),
        "water_steril_m3": H["w_steril"].sum(),
        "water_recycled_m3": H["w_recycled"].sum(), "water_municipal_m3": H["w_municipal"].sum(),
        "permeate_m3": H["permeate"].sum(),
        "fan_MWh": H["fan_kWh"].sum() / 1000,
        "fan_h": int(H["fan_on"].sum()),
        "fan_night_h": int((H["fan_on"].astype(bool) & w["night"]).sum()),
        "pad_h": int(H["pads_on"].sum()),
        "night_h": int(w["night"].sum()),
        "shoulder_h": int(shoulder.sum()),
        "shoulder_pvt_MWh": float((H["pvt_passive"] + H["pvt_film"])[shoulder].sum() / 1000),
        "A_pvt_m2": A_pvt,
    }
    # daytime PVT preheating of wash water: only the temperature-compatible demand that GPU heat and
    # the store leave unmet (GPU heat has priority, so solar preheat never displaces waste heat)
    if cfg.pvt_on and cfg.pvt_preheat and A_pvt > 0:
        if "Tmains" not in w:
            w["Tmains"] = mains_temperature(w)
        key = ("th", climate, A_pvt)
        if key not in _PVT_CACHE:
            _PVT_CACHE[key] = pvt_thermal_hourly(w, A_pvt, w["Tmains"])
        qth = _PVT_CACHE[key]
        pre = np.minimum(np.maximum(usable - H["useful"], 0.0), qth)
    else:
        qth = np.zeros(8760); pre = np.zeros(8760)
    S["host_heat_MWh"] = heat_dem.sum() / 1000
    S["host_compat_MWh"] = usable.sum() / 1000
    S["pvt_th_potential_MWh"] = qth.sum() / 1000
    S["pvt_preheat_MWh"] = pre.sum() / 1000
    S["host_heat_supplied_MWh"] = S["useful_MWh"] + S["pvt_preheat_MWh"]
    S["fuel_saved_MWh"] = S["host_heat_supplied_MWh"] / cfg.boiler_eff
    S["fuel_saved_pvt_MWh"] = S["pvt_preheat_MWh"] / cfg.boiler_eff
    S["co2_saved_t"] = S["fuel_saved_MWh"] * cfg.gas_kgCO2_per_kWh
    S["greywater_m3"] = grey.sum() * cfg.grey_capture
    S["WUE_total_L_kWh"] = S["water_total_m3"] * 1000 / it_kWh
    S["WUE_municipal_L_kWh"] = S["water_municipal_m3"] * 1000 / it_kWh
    rej = S["pvt_passive_MWh"] + S["pvt_film_MWh"] + S["dry_MWh"] + S["adia_MWh"]
    S["cool_elec_MWh"] = S["fan_MWh"] + S["pump_MWh"] + S["ro_MWh"] + S["filmpump_MWh"] + S["steril_MWh"]
    S["cool_elec_kWh_per_kWh_IT"] = S["cool_elec_MWh"] * 1000 / it_kWh
    S["silent_share"] = (S["pvt_passive_MWh"] + S["pvt_film_MWh"]) / max(rej, 1e-9)
    S["recycled_share"] = S["water_recycled_m3"] / max(S["water_total_m3"], 1e-9)
    if keep_hourly:
        S["hourly"] = H
    return S


def climate_summary(w):
    return {
        "T_mean": float(w["T"].mean()), "T_p99": float(np.percentile(w["T"], 99)),
        "Twb_p99": float(np.percentile(w["Twb"], 99)), "RH_mean": float(w["RH"].mean()),
        "night_T_mean": float(w["T"][w["night"]].mean()),
        "night_frac": float(w["night"].mean()),
        "cloud_mean": float(w["cloud"].mean()),
        "hours_T_ge_45": int((w["T"] >= 45).sum()),
        "hours_T_ge_35": int((w["T"] >= 35).sum()),
    }


# ----------------------------------------------------------------------------
# Conventional baseline: open evaporative cooling tower on municipal water
# ----------------------------------------------------------------------------
@dataclass
class TowerConfig:
    T_hot: float = 45.0          # water entering tower
    range_K: float = 10.0        # tower range
    exit_frac: float = 0.6       # exit-air saturation temperature position between Twb and mean water temp
    coc: float = 3.0             # cycles of concentration, municipal make-up
    drift_frac: float = 0.00005  # drift as fraction of circulating water (0.005 %)
    fan_kW_per_kW: float = 0.008 # tower fan, annual average per kW rejected with variable-speed fans
    spray_pump_kW_per_kW: float = 0.004
    pump_kW_per_kW: float = 0.008


def enthalpy(T, w):
    return CP_AIR * T + w * (2501.0 + 1.86 * T)


def tower_hour(Q, T, RH, Twb, tc: TowerConfig):
    """Evaporation (kg), blowdown (kg), drift (kg), electricity (kWh) to reject Q kW for one hour."""
    if Q <= 0:
        return 0.0, 0.0, 0.0, 0.0, 0.0
    T_mean_w = tc.T_hot - tc.range_K / 2.0
    T_ex = Twb + tc.exit_frac * max(T_mean_w - Twb, 0.5)
    w_in = pvt.humidity_ratio(T, RH)
    w_ex = pvt.humidity_ratio(T_ex, 1.0)
    dh = enthalpy(T_ex, w_ex) - enthalpy(T, w_in)
    dw = max(w_ex - w_in, 0.0)
    f_lat = float(np.clip(dw * 2501.0 / max(dh, 1e-6), 0.0, 1.0))
    evap = Q * f_lat / H_FG * 3600.0
    circ = Q / (4.186 * tc.range_K) * 3600.0       # kg circulating
    drift = circ * tc.drift_frac
    blow = max(evap / (tc.coc - 1.0) - drift, 0.0)
    elec = Q * (tc.fan_kW_per_kW + tc.spray_pump_kW_per_kW + tc.pump_kW_per_kW)
    return evap, blow, drift, elec, f_lat


def simulate_tower(w, Q_hourly, tc: TowerConfig = TowerConfig()):
    ev = bl = dr = el = 0.0
    fl = []
    for h in range(8760):
        e, b, d, x, f = tower_hour(Q_hourly[h], w["T"][h], w["RH"][h], w["Twb"][h], tc)
        ev += e; bl += b; dr += d; el += x
        if Q_hourly[h] > 0:
            fl.append(f)
    tot = (ev + bl + dr) / 1000.0
    return {"water_m3": tot, "evap_m3": ev / 1000, "blowdown_m3": bl / 1000, "drift_m3": dr / 1000,
            "elec_MWh": el / 1000, "latent_frac_mean": float(np.mean(fl)) if fl else 0.0}
