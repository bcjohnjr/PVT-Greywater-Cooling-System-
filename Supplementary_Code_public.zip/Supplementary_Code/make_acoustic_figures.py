"""Figures 9 and 10 (fan noise) from results/acoustics.json."""
import os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = HERE if os.path.isdir(os.path.join(HERE, "weather")) else os.path.dirname(HERE)
A = json.load(open(os.path.join(ROOT, "results", "acoustics.json")))
FIG = os.path.join(ROOT, "figures")
os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "figure.dpi": 150})
C_Q, C_S, C_D = "#2a78d6", "#1baf7a", "#eb6834"   # quiet-hours, sunrise-limited, dry cooler
INK, MUTED = "#2c2c2a", "#8a8a85"
FLOOR = 15.0                                        # plotted position for 'no fan operation'
# source level at which ambient + source reaches ambient + 5 dB (50/40 dB(A) presumed ambient)
TH_DAY = A["quiet"]["A"]["Phoenix"]["pvt_shoulder"]["dry"]["day"]["source_threshold_dBA"]
TH_NIGHT = A["quiet"]["A"]["Phoenix"]["pvt_shoulder"]["dry"]["night"]["source_threshold_dBA"]
CL = list(A["central"]["A"].keys())


def nz(v):
    return np.nan if v is None else v


# ---- Fig 9: mean diurnal profile, Case B ------------------------------------
sites = ["Phoenix", "Miami", "Los Angeles"]
fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.9), sharey=True)
hrs = np.arange(24) + 0.5
for ax, c in zip(axs, sites):
    q = A["quiet"]["B"][c]
    ax.axvspan(0, 7, color="#eeeeec", lw=0); ax.axvspan(22, 24, color="#eeeeec", lw=0)
    crit = np.where((np.arange(25) >= 7) & (np.arange(25) < 22), TH_DAY, TH_NIGHT)
    ax.step(np.arange(25), crit, where="post", color=MUTED, lw=1, ls=":")
    ax.plot(hrs, [nz(v) for v in q["pvt_shoulder"]["profile"]["dry"]], color=C_D, lw=2, label="Dry cooler")
    ax.plot(hrs, [nz(v) for v in q["central"]["profile"]["prop"]], color=C_S, lw=2, ls="--",
            label="Proposed, PVT duty ends at sunrise")
    ax.plot(hrs, [nz(v) for v in q["pvt_shoulder"]["profile"]["prop"]], color=C_Q, lw=2,
            label="Proposed, quiet-hours dispatch")
    off = [i for i, v in enumerate(q["pvt_shoulder"]["profile"]["prop"]) if v is None]
    ax.plot(hrs[off], np.full(len(off), FLOOR + 1), ls="none", marker="o", ms=3.5, mfc="white", mec=C_Q)
    ax.set_title(c, fontsize=9, color=INK)
    ax.set_xlim(0, 24); ax.set_xticks([0, 6, 12, 18, 24]); ax.set_ylim(FLOOR, 65)
    ax.grid(axis="y", color="#e5e5e2", lw=0.6)
    ax.set_xlabel("Hour of day")
axs[0].set_ylabel("Energy-mean $L_{pA}$ at 10 m (dB(A))")
axs[2].text(0.3, TH_NIGHT - 2.6, f"night limit,\nsource {TH_NIGHT:.1f}", fontsize=6.5, color=MUTED)
axs[2].text(7.6, TH_DAY + 1.2, f"day limit, source {TH_DAY:.1f}", fontsize=6.5, color=MUTED)
axs[2].text(0.4, FLOOR + 2.2, "○ no fan operation", fontsize=6.5, color=C_Q)
h, l = axs[0].get_legend_handles_labels()
fig.legend(h, l, loc="lower center", ncol=3, frameon=False, fontsize=7.5, bbox_to_anchor=(0.5, -0.04))
fig.tight_layout(rect=(0, 0.07, 1, 1))
fig.savefig(os.path.join(FIG, "Fig9_noise_diurnal.png"), dpi=300, bbox_inches="tight"); plt.close(fig)

# ---- Fig 10: LAeq,day and LAeq,night by climate, both cases -------------------
fig, axs = plt.subplots(2, 2, figsize=(7.4, 5.2), sharey="row")
y = np.arange(len(CL))[::-1]
for j, case in enumerate("AB"):
    ax = axs[0, j]
    pd = [A["quiet"][case][c]["pvt_shoulder"]["prop"]["day"]["LAeq"] for c in CL]
    dd = [A["quiet"][case][c]["pvt_shoulder"]["dry"]["day"]["LAeq"] for c in CL]
    for yi, a, b in zip(y, pd, dd):
        ax.plot([a, b], [yi, yi], color="#d0d0cc", lw=1.5, zorder=1)
        ax.text(57.0, yi, f"{a - b:+.1f} dB", va="center", fontsize=6.8, color=INK)
    ax.scatter(dd, y, s=36, color=C_D, zorder=3, label="Dry cooler", edgecolor="white", lw=1)
    ax.scatter(pd, y, s=36, color=C_Q, zorder=3, marker="s", label="Proposed (hybrid cooler)", edgecolor="white", lw=1)
    ax.axvline(TH_DAY, color=MUTED, ls=":", lw=1)
    ax.set_title(f"({'ab'[j]}) Day 07:00–22:00, Case {case}", fontsize=8.5, loc="left", color=INK)
    ax.set_xlim(15, 63)
    ax = axs[1, j]
    ds = [A["quiet"][case][c]["central"]["prop"]["night"]["LAeq"] for c in CL]
    dn = [A["quiet"][case][c]["pvt_shoulder"]["dry"]["night"]["LAeq"] for c in CL]
    qn = [A["quiet"][case][c]["pvt_shoulder"]["prop"]["night"]["LAeq"] for c in CL]
    ax.scatter([nz(v) for v in dn], y, s=36, color=C_D, zorder=3, label="Dry cooler", edgecolor="white", lw=1)
    ax.scatter([nz(v) for v in ds], y, s=30, color=C_S, marker="^", zorder=3,
               label="Proposed, PVT duty ends at sunrise", edgecolor="white", lw=1)
    ax.scatter([FLOOR + 0.8 if v is None else v for v in qn], y, s=36, marker="o", facecolor="white",
               edgecolor=C_Q, lw=1.4, zorder=3, label="Proposed, quiet-hours dispatch (no fan operation)")
    ax.axvline(TH_NIGHT, color=MUTED, ls=":", lw=1); ax.axvline(40, color=MUTED, ls="-", lw=0.6)
    ax.set_title(f"({'cd'[j]}) Night 22:00–07:00, Case {case}", fontsize=8.5, loc="left", color=INK)
    ax.set_xlim(FLOOR, 52)
    for a in axs[:, j]:
        a.set_yticks(y); a.set_yticklabels(CL); a.grid(axis="x", color="#e5e5e2", lw=0.6)
for a in axs[1]:
    a.set_xlabel("$L_{Aeq}$ at 10 m over the period, annual (dB(A))")
for a in axs[0]:
    a.text(TH_DAY + 0.3, 6.45, f"{TH_DAY:.1f}", fontsize=6.5, color=MUTED)
for a in axs[1]:
    a.set_ylim(-0.8, 6.4)
    a.text(TH_NIGHT + 0.3, -0.6, f"{TH_NIGHT:.1f}", fontsize=6.5, color=MUTED); a.text(39.7, -0.6, "ambient 40", fontsize=6.5, color=MUTED, ha="right")
h0, l0 = axs[0, 0].get_legend_handles_labels(); h1, l1 = axs[1, 0].get_legend_handles_labels()
fig.legend(h0[1:] + h1, l0[1:] + l1, loc="lower center", ncol=2, frameon=False, fontsize=7.3,
           bbox_to_anchor=(0.5, -0.05))
fig.tight_layout(rect=(0, 0.08, 1, 1))
fig.savefig(os.path.join(FIG, "Fig10_noise_by_climate.png"), dpi=300, bbox_inches="tight"); plt.close(fig)
print("Fig9, Fig10 written")
